RP_GetAllocationSummaryOrg4_LM()
{
	web_js_run(
        //"Code=CryptoJS.enc.Utf8.parse(JSON.stringify(header));",
        "Code=eval(query1(LR.getParam('EMPID'),LR.getParam('STARTWEEK'),LR.getParam('STARTYEAR')));",
        //"File=Encrypt_Function.js",
        //"ResultParam=signature2",
        SOURCES,
     //   "Code= newFunc() { return signature2; }", ENDITEM,
        "File=fx_GetAllocationSummaryOrg4.js", ENDITEM,
        LAST);

	web_js_run(
        //"Code=CryptoJS.enc.Utf8.parse(JSON.stringify(header));",
        "Code=retSignature2();",
        //"File=Encrypt_Function.js",
        "ResultParam=signature2",
        SOURCES,
     //   "Code= newFunc() { return signature2; }", ENDITEM,
        "File=fx_GetAllocationSummaryOrg4.js", ENDITEM,
        LAST);
	
	///*********************** Add the Authorization Bearer Value *******************//
	web_add_auto_header("Authorization","{Authorization_Value}");
	
	web_add_header("Access-Control-Request-Headers", 
		"access-control-allow-origin,authorization,content-type,parameters");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"http://dtwebkubept");
	
	// API getting called when loading Summary Page
	sprintf(strTranFullName, "%s_%s",lr_eval_string("{LRGen}"),"DT_ReportPage_01_LightManager_GetAllocationSummaryOrg4");

	lr_start_transaction(strTranFullName);
	
	web_custom_request("GetAllocationSummaryOrg4s", 
		"URL=http://dreamteampt/manager/api/allocationmanager/GetAllocationSummaryOrg4s", 
		"Method=OPTIONS", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_save_param("Response",
	                   "LB=",
	                   "RB=",
	                   LAST);
	
	// "result":[]
	web_reg_find("Text=\"result\":{}",
	             "SaveCount=NoResultFetch",
	             LAST);	
	
	// "result":{"org4Data":[
	web_reg_find("Text=\"result\":{\"org4Data\":[]",
	             "SaveCount=NoResultFetchOrg4Data",
	             LAST);	

	web_reg_find("Text={\"status\":null",
	             "SaveCount=FirstResponse",
	             LAST);
	
	web_reg_find("Text=\"isSuccess\":true",
	             "SaveCount=MiddleResponse",
	             LAST);	

	web_add_header("Access-Control-Allow-Origin", 
		"*");

//	web_add_header("parameters", 
//		"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJxdWVyeVN0cmluZyI6eyJza2lwIjoiMCIsImxpbWl0IjoiMjAiLCJlbXBsb3llZUlkIjoiMTAzNDYyIiwic3RhcnRZZWFyIjoiMjAxOCIsInN0YXJ0V2VlayI6IjI2In0sImlhdCI6MTUyOTQ3NDIxMn0.Xil5d5FLxnI2qrmDEALJ8tG2RDOzSUS14fXlvgZ7GAA");

	web_add_header("parameters", 
		"{signature2}");
	               
	web_url("GetAllocationSummaryOrg4s_2", 
		"URL=http://dreamteampt/manager/api/allocationmanager/GetAllocationSummaryOrg4s", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://dtwebkubept/", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);
	
	if ((web_get_int_property(HTTP_INFO_RETURN_CODE)) >= 400  )
	{
	   lr_error_message("Error occured while executing DT_ReportPage_01_LightManager_GetAllocationSummaryOrg4, Error occured with Error code HTTP[%3i],Iteration:[%s],Timestamp:[%s],EMPID:[%s],Response:[%s]", web_get_int_property(HTTP_INFO_RETURN_CODE),lr_eval_string("{ITERNO}"),lr_eval_string("{TIMESTAMP}"),lr_eval_string("{EMPID}"),lr_eval_string("{Response}"));
	   
	   lr_end_transaction(strTranFullName,LR_FAIL);

       lr_exit(LR_EXIT_ACTION_AND_CONTINUE,LR_FAIL);
	}
	
	else if (atoi(lr_eval_string("{NoResultFetch}")) > 0)
	{
	   lr_error_message("No Results data fetched for API DT_ReportPage_01_LightManager_GetAllocationSummaryOrg4 executed for Iteration:[%s],Timestamp:[%s],EMPID:[%s],Response:[%s]",lr_eval_string("{ITERNO}"),lr_eval_string("{TIMESTAMP}"),lr_eval_string("{EMPID}"),lr_eval_string("{Response}"));
	   
	   lr_end_transaction(strTranFullName,LR_FAIL);

       lr_exit(LR_EXIT_ACTION_AND_CONTINUE,LR_FAIL);
	}
	
	else if (atoi(lr_eval_string("{NoResultFetchOrg4Data}")) > 0)
	{
	   lr_error_message("No Results data fetched for Org4Data for API DT_ReportPage_01_LightManager_GetAllocationSummaryOrg4 executed for Iteration:[%s],Timestamp:[%s],EMPID:[%s],Response:[%s]",lr_eval_string("{ITERNO}"),lr_eval_string("{TIMESTAMP}"),lr_eval_string("{EMPID}"),lr_eval_string("{Response}"));
	   
	   lr_end_transaction(strTranFullName,LR_FAIL);

       lr_exit(LR_EXIT_ACTION_AND_CONTINUE,LR_FAIL);
	}
	
	else if (atoi(lr_eval_string("{FirstResponse}")) == 0 || atoi(lr_eval_string("{MiddleResponse}")) == 0)
	{
	   lr_error_message("DT_ReportPage_01_LightManager_GetAllocationSummaryOrg4 not executed successfully at Iteration:[%s],Timestamp:[%s],EMPID:[%s],Response:[%s]",lr_eval_string("{ITERNO}"),lr_eval_string("{TIMESTAMP}"),lr_eval_string("{EMPID}"),lr_eval_string("{Response}"));
	   
	   lr_end_transaction(strTranFullName,LR_FAIL);

       lr_exit(LR_EXIT_ACTION_AND_CONTINUE,LR_FAIL);
	}
	
	lr_end_transaction(strTranFullName,LR_AUTO);
	
	web_revert_auto_header("Authorization");
	
	web_revert_auto_header("Origin");
	
	web_revert_auto_header("Access-Control-Allow-Origin");	
	
	return 0;
}
