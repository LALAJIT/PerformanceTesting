vuser_init()
{
	Restart:
		
	web_set_max_html_param_len("999999");
	
	web_set_user("CORP.AMDOCS.COM\\{NTNET}","{PASSWORD}","mysite:80");

	web_set_user("CORP.AMDOCS.COM\\{NTNET}","{PASSWORD}","dtwebkubept:80");

	web_reg_find("Text=DreamTeamClient", 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("dtwebkubept", 
		"URL=http://dtwebkubept/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("INITIAL_AUTH", "BASIC");
	
	web_set_sockets_option("SSL_VERSION", "2&3");
	
	web_reg_save_param("Response",
	                   "LB=",
	                   "RB=",
	                   LAST);
	
	// {"uid":"dreamteamuser0003"
	web_reg_save_param_ex(
		"ParamName=UID",
		//"LB={\"uid\":\"AJLAL\",\"token\":",
		"LB={\"uid\":\"",
		"RB=\"",
		SEARCH_FILTERS,
		"Scope=Body",
		"RequestUrl=*/getuser/*",
		LAST);
	
	/*Correlation comment - Do not change!  Original value='"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6IkFKTEFMIiwibmJmIjoxNTI4ODg5Nzk1LCJleHAiOjE1Mjg4OTMzOTUsImlhdCI6MTUyODg4OTc5NX0.sDdjl5n6sj7hs8Jb1Wfr6lvDtpahLMslIy80d0e1dhk"' Name ='AuthorizationToken' Type ='Manual'*/
	web_reg_save_param_ex(
		"ParamName=AuthorizationToken",
		//"LB={\"uid\":\"AJLAL\",\"token\":",
		"LB=,\"token\":",
		"RB=}",
		SEARCH_FILTERS,
		"Scope=Body",
		"RequestUrl=*/getuser/*",
		LAST);

	/*Correlation comment - Do not change!  Original value='Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6IkFKTEFMIiwibmJmIjoxNTI4ODg5Nzk1LCJleHAiOjE1Mjg4OTMzOTUsImlhdCI6MTUyODg4OTc5NX0.sDdjl5n6sj7hs8Jb1Wfr6lvDtpahLMslIy80d0e1dhk' Name ='Authorization_Value' Type ='Manual'*/
	web_reg_save_param_ex(
		"ParamName=Authorization_Value",
		"LB=Authorization: ",
		"RB=\r\n",
		SEARCH_FILTERS,
		"Scope=Headers",
		"RequestUrl=*/getuser/*",
		LAST);

	//sprintf(strTranFullName, "%s_%s",lr_eval_string("{LRGen}"),"DT_HomePage_02_LightManagers_GetUser");

	//lr_start_transaction(strTranFullName);
	
	web_url("getuser", 
		"URL=http://dtwebkubept/DreamTeamAuth/getuser/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://dtwebkubept/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);
	
	if ((web_get_int_property(HTTP_INFO_RETURN_CODE)) >= 400  )
	{
	   lr_error_message("Error occured while executing GetUser Request, Error occured with Error code HTTP[%3i],Iteration:[%s],Timestamp:[%s],NTNET:[%s],EMPID:[%s],Response:[%s]", web_get_int_property(HTTP_INFO_RETURN_CODE),lr_eval_string("{ITERNO}"),lr_eval_string("{TIMESTAMP}"),lr_eval_string("{NTNET}"),lr_eval_string(""),lr_eval_string("{Response}"));
	   
	   //lr_end_transaction(strTranFullName,LR_FAIL);

       //lr_exit(LR_EXIT_ACTION_AND_CONTINUE,LR_FAIL);
       
       goto Restart;
	}
	
	if(strcmp(lr_eval_string("{UID}"),lr_eval_string("{NTNET}")) != 0)
	{
		lr_error_message("Incorrect Response received for GetUser API,Iteration:[%s],Timestamp:[%s],NTNET:[%s],UID:[%s],EMPID:[%s],Response:[%s]",lr_eval_string("{ITERNO}"),lr_eval_string("{TIMESTAMP}"),lr_eval_string("{NTNET}"),lr_eval_string("{UID}"),lr_eval_string(""),lr_eval_string("{Response}"));
	   
	   //lr_end_transaction(strTranFullName,LR_FAIL);

       //lr_exit(LR_EXIT_ACTION_AND_CONTINUE,LR_FAIL);
       
       goto Restart;		
		
	}
	
	return 0;
}
